/*
 * BankingApp.cpp
 *
 *  Created on: Oct 7, 2023
 *      Author: ashlyn
 */
#include <iostream>
#include <iomanip>
#include "BankingApp.h"
using namespace std;


// print off the prompts for the user
double BankingApp:: GatherUserInvest(){
	cout << "Initial Investment Amount:";
	cin >> userInvest;
	return userInvest;
}
double BankingApp:: GatherUserDeposit(){
	cout << "Monthly Deposit:";
	cin >> userDeposit;
	return userDeposit;
}
double BankingApp:: GatherUserInterest(){
	cout << "Annual Interest:";
	cin >> userInterest;
	return userInterest;
}
int BankingApp:: GatherUserYears(){
	cout << "Number of Years:";
	cin >> userYears;
	return userYears;
}
//loops 12 times for every year the simulation runs to find the total with no monthly investments
double BankingApp:: NoDepoPerYear(double invest, double interestRate){
	double finalAmount = invest;
	for (int i = 0; i < 12; i++){

		finalAmount = finalAmount + (invest * ((interestRate/100)/12));
	}
	return finalAmount;
}

double BankingApp :: TotalPerYear(double invest, double deposit, double interestRate){
	double finalAmount = invest;
	for (int i = 0; i < 12; i++){
		finalAmount = finalAmount + deposit;
		finalAmount = finalAmount + ((invest + deposit) * ((interestRate/100)/12));


	}
	return finalAmount;
}
//prints the main display
void BankingApp :: DisplayHeader(string header, char symbol){
	cout << setw(20)<<setfill(symbol)<<endl;
	cout<<""<<endl;
	cout << header<< endl;
	cout << setw(20)<<setfill(symbol)<<endl;
	cout<<""<<endl;
}
void BankingApp:: DisplayRow(int year, double yearEnd, double yearInterest){
	cout << year << "    ";
	cout  << yearEnd<< "    ";
	cout << yearInterest <<endl;
}
void BankingApp:: PrintMenu(){
	cout<< "1 - Change the initial investment"<<endl;
	cout<< "2 - Change the deposit amount"<<endl;
	cout<< "3 - Change the interest rate" << endl;
	cout << "4 - Change the amount of time" << endl;
	cout<< "5 - Exit the simulation" << endl;
}
// sets and gets all of the private values
void BankingApp :: SetInvestment(double uInvest){
	investment = uInvest;
}
double BankingApp :: GetInvestment(){
	return investment;
}
void BankingApp :: SetDeposit(double uDepo){
	deposit = uDepo;
}
double BankingApp :: GetDeposit(){
	return deposit;
}
void BankingApp :: SetInterest(double uInterest){
	interest = uInterest;
}
double BankingApp :: GetInterest(){
	return interest;
}
void BankingApp :: SetYears(int uYear){
	years = uYear;
}
int BankingApp :: GetYears(){
	return years;
}
void BankingApp:: SetAll(double inv, double d, double intr, int y){
	investment = inv;
	deposit = d;
	interest = intr;
	years = y;
}


