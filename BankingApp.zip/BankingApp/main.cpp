/*
 * main.cpp
 *
 *  Created on: Oct 7, 2023
 *      Author: ashly
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <stdexcept>

#include "BankingApp.h"
using namespace std;
int main(){
	int userInput = 0;
	BankingApp user;
	//creates a space
	user.DisplayHeader("Data Input", '*');
	user.userInvest = user.GatherUserInvest();
	user.userDeposit = user.GatherUserDeposit();
	user.userInterest = user.GatherUserInterest();
	user.userYears = user.GatherUserYears();
	//prints a menu, but initializes the prompts separate so I can store in main and so it is easier to change them later
	user.SetAll(user.userInvest, user.userDeposit, user.userInterest, user.userYears);
	//sets all of the values at once

	double noDepoAmount[user.GetYears()];
	double noDepoInterestAmount[user.GetYears()];
	double depoAmount[user.GetYears()];
	double depoInterestAmount[user.GetYears()];
	// fixes the max decimals for the output
	std::cout << fixed;
	std::cout << setprecision(2);
	//initializes local storing arrays to display values later
	while (userInput !=5){
		user.DisplayHeader("Loading Your Data...", '*');
		//creates a loop for menu to access
		for (int i=0; i< user.GetYears(); i++){
		// a loop for every year the simulation runs, tracking the values without a monthly deposit
			noDepoAmount[i] = user.NoDepoPerYear(user.userInvest, user.GetInterest());
			//puts the final value for the year in an array
			noDepoInterestAmount[i] = noDepoAmount[i] - user.userInvest;
			//puts the interest for the year in the same spot as the final value
			user.userInvest = noDepoAmount[i];
		}
		user.userInvest = user.GetInvestment();
		//resets userInterest for use later
		for (int i = 0; i < user.GetYears(); i ++){
		//a loop for every year the simulation runs, tracking values with a monthly deposit
		depoAmount[i] = user.TotalPerYear(user.userInvest, user.GetDeposit(), user.GetInterest());
		depoInterestAmount[i] = (depoAmount[i] + user.GetDeposit()) *(user.GetInterest()/100);
		user.userInvest = depoAmount[i];
		}
		user.DisplayHeader("Balance and Interest without additional deposits", '=');
		for(int i=0; i<user.GetYears(); i++){
			user.DisplayRow(i+1, noDepoAmount[i], noDepoInterestAmount[i]);
		}
		cout<< endl;
		user.DisplayHeader("Balance and Interest with additional deposits", '=');
		for(int i=0; i<user.GetYears(); i++){
			user.DisplayRow(i+1, depoAmount[i], depoInterestAmount[i]);
		}
		cout<< endl;
		user.DisplayHeader("Would you like to change anything?",'*');
		user.PrintMenu();
		cin >> userInput;
		switch(userInput){
		case 1:
			user.userInvest = user.GatherUserInvest();
			user.SetInvestment(user.userInvest);
			continue;
		case 2:
			user.userDeposit = user.GatherUserDeposit();
			user.SetDeposit(user.userDeposit);
			continue;
		case 3:
			user.userInterest = user.GatherUserInterest();
			user.SetInterest(user.userInterest);
			continue;
		case 4:
			user.userYears = user.GatherUserYears();
			user.SetYears(user.userYears);
			continue;
		case 5:
			cout << "Thank you for playing" <<endl;
			break;
		default:
			cout<< "Invalid Input"<< endl;
			continue;
		}
		}
	return 0;
}


