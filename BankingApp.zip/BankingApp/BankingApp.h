/*
 * BankingApp.h
 *
 *  Created on: Oct 7, 2023
 *      Author: ashly
 */

#ifndef BANKINGAPP_H
#define BANKINGAPP_H


#include <string>
using namespace std;

class BankingApp {
	public:
	// initializes storage for subjective user values
		double userInvest = 0.0;
		double userDeposit = 0.0;
		double userInterest = 0.0;
		int userYears = 0;
		// initializes methods to get user feedback
		double GatherUserInvest();
		double GatherUserDeposit();
		double GatherUserInterest();
		int GatherUserYears();
		//initializes methods to set up the final total rates
		double NoDepoPerYear(
				double invest,
				double interestRate
				);
		double TotalPerYear(
				double invest,
				double deposit,
				double interestRate
				);
		// prints the final display
		void DisplayHeader(
				string header,
				char symbol
				);
		void DisplayRow(
				int years,
				double yearEnd,
				double yearInterest
				);
		void PrintMenu();
		//sets and gets all of the values
		void SetInvestment(double uInvest);
		double GetInvestment();
		void SetDeposit(double uDepo);
		double GetDeposit();
		void SetInterest(double uInterest);
		double GetInterest();
		void SetYears(int uYear);
		int GetYears();
		void SetAll(double inv, double d, double intr, int y);
	private:
		//defines the harder to change values that need setters and getters
		double investment = 0.0;
		double deposit = 0.0;
		double interest = 0.0;
		int years = 0;


};
#endif


