/*
 * clocks.cpp
 *
 *  Created on: Sep 15, 2023
 *      Author: Ashlyn Barlow
 */

#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;


void Clock24(vector<string>& clockInput, bool& clock, int userHour, int userMin = 0, int userSec = 0){
	//adds userHour, makes default values for userMin and userSec or adds submissions
		if (userHour > 24 || userHour < 1){
			cout << "Time not found";
			clock = false;
			return;
		}
		//checks validity of hour
		if (userMin > 59 || userMin < 0){
			cout << "Time not found";
			clock = false;
			return;
		}
		//checks validity of minute
		if (userSec > 59 || userSec < 0){
			cout << "Time not found";
			clock = false;
			return;
		}
		//checks validity of second
		if (userHour < 10){
			clockInput.at(0) = "0" + to_string(userHour);
		}
		else {
			clockInput.at(0) = to_string(userHour);
		}
		if (userMin < 10){
			clockInput.at(2) = "0" + to_string(userMin);
		}
		else{
			clockInput.at(2) = to_string(userMin);
		}
		if (userSec < 10){
			clockInput.at(3) = "0" + to_string(userSec);
		}
		else{
			clockInput.at(3) = to_string(userSec);
		}
		//puts the user values into a vector for display
}

void Clock12(vector<string>& clockInput, bool& clock, int userHour){
	//Separates the 12 hour function for readability and easy access

	if (userHour > 12 || userHour < 1){
		clock = false;
		return;
	}
	//checks validity of hour
	if (userHour < 10){
		clockInput.at(1) = "0" + to_string(userHour);
	}
	else {
		clockInput.at(1) = to_string(userHour);
	}
	//adds the 12 hour version to the vector


}

void PrintClock(const vector<string>& clockInput){
	//print clock
	cout << setfill('*') << setw(30) << "" <<endl;
	cout << setw(15) << left << "12 Hour Clock" << "~";
	cout << setw(15) << right << "24 Hour Clock" << endl;
	cout << setfill('*') << setw(30) << "" << endl;
	// make fancy header
	cout << clockInput.at(1) << " : " << clockInput.at(2) << " : " << clockInput.at(3);
	cout << setfill('*') <<setw(6)<< "";
	cout << clockInput.at(0) << " : " << clockInput.at(2) << " : " << clockInput.at(3)<< endl;
	cout << setfill('*') << setw(30) << "" << endl;
	//make fancy clock


}

int PrintMenu(){
	int userInput;
	cout << setfill('*') << setw(30) << "" << endl;
	cout << setfill('*') << setw(5) << "";
	cout << "Select your option: "<< setfill('*') << setw(5) << "" << endl;
	cout << setfill('*') << setw(7) << "";
	cout << "1) Add One Hour "<< setfill('*') << setw(7) << "" <<endl;
	cout << setfill('*') << setw(6) << "";
	cout << "2) Add One Minute "<< setfill('*') << setw(6) << "" << endl;
	cout << setfill('*') << setw(6) << "";
	cout << "3) Add One Second "<< setfill('*') << setw(6) << "" <<endl;
	cout << setfill('*') << setw(7) << "";
	cout << "4) Exit program " << setfill('*') << setw(7) << ""<< endl;
	//puts one of the decoration line with the main statement to save space, but keeps the other in the middle to act as a buffer and make the stements easier to see in the code.
	cin >> userInput;
	// creates menu and gathers input
	return userInput;
}

void MenuOption(int num, int& currHour, int& curr12Hour, int& currMin, int& currSec, bool& clock){
	if (num == 1){
		currHour = currHour + 1;
		curr12Hour = curr12Hour +1;
		return;
	}
	if (num == 2){
		currMin = currMin + 1;
		return;
	}
	if (num == 3){
		currSec = currSec + 1;
		return;
	}
	if (num == 4){
		clock = false;
		return;
	}
	else{
		cout << "Invalid entry";
		return;
	}

}
int main(){
	int currHour;
	int curr12Hour;
	int currMin;
	int currSec;
	int userInput;
	//creates values so we can input into them
	bool clock = true;
	// creates loop
	cout<<"Input your time";
	cin>> currHour >> currMin >> currSec;
	//Gathers initial time
	vector <string> clockInput(4);
	while (clock){
		if (currHour > 12 && currHour < 25){
			curr12Hour = currHour - 12;
			//converts possible 24 hour to 12 hour
		}
		else{
			curr12Hour = currHour;
		//adds 12 hour int
		}
		Clock24(clockInput, clock, currHour, currMin, currSec);
		//puts the 24 hour clock into the vector
		Clock12(clockInput, clock, curr12Hour);
		//puts the 12 hour clock into the vector
		if (!clock){
			break;
		}
		PrintClock(clockInput);
		//prints the clock using the vector
		userInput = PrintMenu();
		//activates print menu and collects user input
		MenuOption(userInput, currHour, curr12Hour, currMin, currSec, clock);
		//makes sure the user's inputs are used
	}
	return 0;
}


